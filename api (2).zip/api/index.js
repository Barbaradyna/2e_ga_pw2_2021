const express = require('express')
const server = express()
const mysql = require('mysql2')
const banco = mysql.createPool({
    host: 'localhost',
    port: '3306',
    database: '2e_ga_2021',
    user: 'root',
    password: 'minas',
})

server.get('/clientes', (res, req)=>{
    const SQL = 'SELECT * FROM clientes'

    banco.getConnection((erro, con)=>{
        if(erro){
            return res.status(500).send({
                mensagem: 'Erro no servidor',
                detalhes: erro
            })
        }

        con.query(SQL,(erro, resultados)=>{
            con.release()

            if (erro){
                return res.status(500).send({
                    mensagem: 'Erro ao executar a consulta',
                    detalhes: erro
                })
            }

            return res.status(200).send({
                mensagem: 'Dados executados com sucesso',
                data: resultados
            })
        })
    })
})
server.get('/testarconexao', (req, res,) => {
    banco.getConnection((erro, con)=>{
        if (erro){
            return res.status(500).send({
                mensagem: 'Erro no servidor',
                detalhes: erro
            })
        }
       
        con.release()

        return res.status(200).send ({
            mensagem: 'Conexão estabelecida com sucesso!'
        })
    })
    return res.status(200).send({
        mensagem: "Servidor funcionando!"
    })
})

server.listen(3000, () => {
    console.log("Executando")
})

